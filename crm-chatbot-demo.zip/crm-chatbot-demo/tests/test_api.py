import os
os.environ["DATABASE_URL"] = "sqlite:///./test.db"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402
from app.chatbot import match_faq  # noqa: E402

client = TestClient(app)


def test_health():
    assert client.get("/health").json() == {"status": "ok"}


def test_faq_matching_known_and_unknown():
    _, high = match_faq("how do I track my order")
    _, low = match_faq("can you gift wrap a book")
    assert high > 0.34 > low


def test_known_question_is_auto_resolved():
    r = client.post("/chat", json={"message": "What is your return policy?"})
    body = r.json()
    assert r.status_code == 200
    assert body["auto_resolved"] is True
    assert "7 days" in body["answer"]


def test_unknown_question_creates_ticket_and_can_be_resolved():
    r = client.post("/chat", json={"message": "Can you gift wrap a book?"})
    body = r.json()
    assert body["auto_resolved"] is False and body["ticket_id"]
    tid = body["ticket_id"]
    assert any(t["id"] == tid for t in client.get("/tickets?status=open").json())
    assert client.patch(f"/tickets/{tid}/resolve").json()["status"] == "resolved"


def test_empty_message_rejected():
    assert client.post("/chat", json={"message": "  "}).status_code == 422


def test_customer_create_and_duplicate():
    payload = {"name": "Test User", "email": "test.user@example.com"}
    assert client.post("/customers", json=payload).status_code in (201, 409)
    assert client.post("/customers", json=payload).status_code == 409


def test_stats_shape():
    s = client.get("/stats").json()
    assert {"customers", "chats", "auto_resolved", "auto_resolution_rate", "open_tickets"} <= s.keys()
