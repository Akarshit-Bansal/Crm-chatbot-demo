# CRM + Support Chatbot (Demo)

A small full-stack demo of a customer CRM with a support chatbot. The bot answers common
questions on its own and **escalates anything it is unsure about to a human as a ticket**.
A dashboard shows the share of chats the bot resolved without help.

> This is a portfolio demo with fake data. It is a simplified rebuild of the ideas from a
> production CRM and MIS I worked on. It contains no company code or customer data.

## Features
- REST API built with **FastAPI**, **SQLAlchemy** and **Pydantic**
- Customer management, chat logging, ticket creation and resolution
- Chatbot with a confidence threshold: confident answers are sent, the rest become tickets
- Optional **AWS Bedrock** mode for model-generated answers grounded in the FAQ
- Reporting endpoint with the bot's auto-resolution rate
- Single-page dashboard with live chat and ticket queue
- **PostgreSQL** via Docker Compose (SQLite by default for quick local runs)
- **Pytest** tests and a **GitHub Actions** pipeline (tests, then Docker build)

## Run locally
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://localhost:8000 for the dashboard and http://localhost:8000/docs for the API docs.

## Run with Docker and PostgreSQL
```bash
docker compose up --build
```

## Run the tests
```bash
pytest -q
```

## Use AWS Bedrock (optional)
Configure AWS credentials, then:
```bash
export USE_BEDROCK=true AWS_REGION=us-east-1
uvicorn app.main:app --reload
```
If Bedrock is unavailable, the app falls back to the built-in FAQ matcher.

## API overview
| Method | Path | Purpose |
|---|---|---|
| POST | `/chat` | Ask the chatbot. Returns an answer or a ticket number |
| GET/POST | `/customers` | List or create customers |
| GET | `/tickets?status=open` | Tickets waiting for a human |
| PATCH | `/tickets/{id}/resolve` | Mark a ticket resolved |
| GET | `/stats` | Chats, open tickets and auto-resolution rate |

## Project structure
```
app/
  main.py       routes
  chatbot.py    FAQ matcher + optional Bedrock
  models.py     SQLAlchemy models
  schemas.py    request/response models
  seed.py       fake demo customers
  static/       dashboard
tests/          pytest suite
```

## Ideas for next steps
Authentication, Alembic migrations, semantic search with embeddings, conversation history in prompts.
