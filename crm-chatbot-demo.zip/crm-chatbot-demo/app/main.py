from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func
from sqlalchemy.orm import Session

from . import models, schemas, chatbot
from .database import Base, engine, get_db, SessionLocal
from .seed import seed

Base.metadata.create_all(bind=engine)
with SessionLocal() as _db:
    seed(_db)

app = FastAPI(title="CRM + Support Chatbot (Demo)",
              description="Demo CRM with an AI support chatbot that escalates to humans.")
STATIC = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(STATIC / "index.html")


@app.get("/health")
def health():
    return {"status": "ok"}


# ---- Customers ----
@app.post("/customers", response_model=schemas.CustomerOut, status_code=201)
def create_customer(data: schemas.CustomerCreate, db: Session = Depends(get_db)):
    if db.query(models.Customer).filter_by(email=data.email).first():
        raise HTTPException(409, "A customer with this email already exists")
    customer = models.Customer(**data.model_dump())
    db.add(customer)
    db.commit()
    db.refresh(customer)
    return customer


@app.get("/customers", response_model=list[schemas.CustomerOut])
def list_customers(db: Session = Depends(get_db)):
    return db.query(models.Customer).order_by(models.Customer.id).all()


# ---- Chatbot ----
@app.post("/chat", response_model=schemas.ChatResponse)
def chat(req: schemas.ChatRequest, db: Session = Depends(get_db)):
    if not req.message.strip():
        raise HTTPException(422, "Message cannot be empty")
    reply = chatbot.get_reply(req.message)
    ticket_id = None
    answer = reply.answer
    if not reply.auto_resolved:
        ticket = models.Ticket(customer_id=req.customer_id, question=req.message)
        db.add(ticket)
        db.flush()
        ticket_id = ticket.id
        answer = ("I'm not sure about that one, so I've passed it to our team. "
                  f"Your ticket number is #{ticket_id}.")
    db.add(models.ChatLog(customer_id=req.customer_id, question=req.message, answer=answer,
                          confidence=reply.confidence, auto_resolved=reply.auto_resolved))
    db.commit()
    return schemas.ChatResponse(answer=answer, confidence=reply.confidence,
                                auto_resolved=reply.auto_resolved, ticket_id=ticket_id)


# ---- Tickets ----
@app.get("/tickets", response_model=list[schemas.TicketOut])
def list_tickets(status: str | None = None, db: Session = Depends(get_db)):
    q = db.query(models.Ticket)
    if status:
        q = q.filter_by(status=status)
    return q.order_by(models.Ticket.id.desc()).all()


@app.patch("/tickets/{ticket_id}/resolve", response_model=schemas.TicketOut)
def resolve_ticket(ticket_id: int, db: Session = Depends(get_db)):
    ticket = db.get(models.Ticket, ticket_id)
    if not ticket:
        raise HTTPException(404, "Ticket not found")
    ticket.status = "resolved"
    db.commit()
    db.refresh(ticket)
    return ticket


# ---- Reporting ----
@app.get("/stats")
def stats(db: Session = Depends(get_db)):
    total = db.query(func.count(models.ChatLog.id)).scalar() or 0
    resolved = db.query(func.count(models.ChatLog.id)).filter_by(auto_resolved=True).scalar() or 0
    return {
        "customers": db.query(func.count(models.Customer.id)).scalar(),
        "chats": total,
        "auto_resolved": resolved,
        "auto_resolution_rate": round(resolved / total * 100, 1) if total else 0.0,
        "open_tickets": db.query(func.count(models.Ticket.id)).filter_by(status="open").scalar(),
    }
