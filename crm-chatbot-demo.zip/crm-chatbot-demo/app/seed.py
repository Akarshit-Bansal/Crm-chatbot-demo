"""Fake demo data only. No real customer information."""
from sqlalchemy.orm import Session
from .models import Customer

DEMO = [
    ("Aarav Sharma", "aarav@example.com", "+91-90000-00001"),
    ("Diya Verma", "diya@example.com", "+91-90000-00002"),
    ("Kabir Singh", "kabir@example.com", "+91-90000-00003"),
    ("Meera Iyer", "meera@example.com", "+91-90000-00004"),
]


def seed(db: Session) -> None:
    if db.query(Customer).count() == 0:
        db.add_all(Customer(name=n, email=e, phone=p) for n, e, p in DEMO)
        db.commit()
