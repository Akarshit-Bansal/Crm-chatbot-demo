"""Chatbot logic.

Default mode: a small FAQ matcher (no cloud account needed, good for demos and tests).
Optional mode: set USE_BEDROCK=true to answer with an AWS Bedrock model, using the same
FAQ as grounding context. If the bot is not confident, the caller escalates to a human.
"""
import os
import re
from dataclasses import dataclass

FAQ = [
    ("How do I track my order?",
     "You can track your order from the Orders page using your order number. "
     "Tracking updates within 24 hours of dispatch."),
    ("What is your return policy?",
     "Books can be returned within 7 days of delivery if unused and in original condition."),
    ("How long does delivery take?",
     "Standard delivery takes 3-5 working days. Metro cities usually receive orders in 2-3 days."),
    ("Do you offer bulk discounts for schools?",
     "Yes. Orders of 50+ books qualify for a bulk discount. Share your list with our sales team for a quote."),
    ("How can I get an invoice?",
     "Invoices are emailed after dispatch. You can also download them from the Orders page."),
    ("What payment methods do you accept?",
     "We accept UPI, debit/credit cards, net banking and cash on delivery for eligible pincodes."),
    ("How do I cancel my order?",
     "Orders can be cancelled before dispatch from the Orders page. After dispatch, use the return process."),
]

STOPWORDS = {"the", "a", "an", "is", "are", "do", "does", "i", "my", "you", "your", "how",
             "what", "can", "to", "of", "for", "me", "it", "in", "on", "and", "or", "get"}
CONFIDENCE_THRESHOLD = 0.34


@dataclass
class BotReply:
    answer: str
    confidence: float
    auto_resolved: bool


def _tokens(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return {w.rstrip("s") for w in words if w not in STOPWORDS}


def match_faq(message: str) -> tuple[str, float]:
    """Return best FAQ answer and a 0-1 confidence score (token overlap)."""
    query = _tokens(message)
    if not query:
        return "", 0.0
    best_answer, best_score = "", 0.0
    for question, answer in FAQ:
        full = _tokens(question + " " + answer)
        title = _tokens(question)
        score = len(query & title) / len(query | title)
        score += 0.25 * (len(query & full) / len(query))
        if score > best_score:
            best_answer, best_score = answer, score
    return best_answer, round(min(best_score, 1.0), 2)


def _bedrock_answer(message: str) -> str:
    import boto3  # imported lazily so the demo runs without AWS
    client = boto3.client("bedrock-runtime", region_name=os.getenv("AWS_REGION", "us-east-1"))
    context = "\n".join(f"Q: {q}\nA: {a}" for q, a in FAQ)
    system = ("You are a customer support assistant. Answer ONLY using the FAQ below. "
              "If the answer is not in the FAQ, reply exactly: ESCALATE.\n\n" + context)
    resp = client.converse(
        modelId=os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-haiku-20240307-v1:0"),
        system=[{"text": system}],
        messages=[{"role": "user", "content": [{"text": message}]}],
        inferenceConfig={"maxTokens": 300, "temperature": 0.1},
    )
    return resp["output"]["message"]["content"][0]["text"].strip()


def get_reply(message: str) -> BotReply:
    if os.getenv("USE_BEDROCK", "false").lower() == "true":
        try:
            text = _bedrock_answer(message)
            if text and text != "ESCALATE":
                return BotReply(text, 0.9, True)
            return BotReply("", 0.0, False)
        except Exception:
            pass  # fall back to the FAQ matcher if AWS is unavailable
    answer, score = match_faq(message)
    return BotReply(answer, score, score >= CONFIDENCE_THRESHOLD)
