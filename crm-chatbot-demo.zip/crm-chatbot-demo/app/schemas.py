from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict


class CustomerCreate(BaseModel):
    name: str
    email: str
    phone: Optional[str] = None


class CustomerOut(CustomerCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime


class ChatRequest(BaseModel):
    message: str
    customer_id: Optional[int] = None


class ChatResponse(BaseModel):
    answer: str
    confidence: float
    auto_resolved: bool
    ticket_id: Optional[int] = None


class TicketOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    customer_id: Optional[int]
    question: str
    status: str
    created_at: datetime
